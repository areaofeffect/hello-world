## Almost Pong Game
Ping Pong game simulation.
